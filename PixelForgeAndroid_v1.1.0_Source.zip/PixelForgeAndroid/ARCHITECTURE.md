# PixelForge Android — Architecture

## Current implementation boundary

PixelForge is a native Android/Kotlin application. It is a real editable-project prototype, not a Photoshop replacement yet. The current milestone covers raster-image import, normalized brush strokes, an eraser model, basic text elements, layer visibility/opacity/order/deletion, undo snapshots, `.pfx` project archives, and PNG export.

## Package boundaries

- `com.pixelforge.editor.MainActivity`: Compose screen and interaction orchestration. This is the current composition root; UI decomposition is a planned refactor.
- `com.pixelforge.editor.model`: document primitives (`EditorLayer`, `PaintStroke`, `TextElement`). Model coordinates are normalized to the document, not the screen.
- `com.pixelforge.editor.render`: viewport fitting and stroke preview primitives. The CPU export renderer and live layer preview compositing are implemented in `render/DocumentRenderer.kt`.
- `com.pixelforge.editor.io`: bounded temporary-file image decoding and `.pfx` archive serialization. A project archive stores `project.json`, optional `base.png`, and embedded font files.

## Rendering strategy

1. Store brush points in normalized document coordinates.
2. Render the source image aspect-fit into the viewport.
3. Composite visible layers in stack order, respecting layer opacity.
4. Render/export on a background dispatcher when work is expensive.
5. Next performance milestone: command-based history, tile-based raster backing, cache invalidation, and a GPU backend only where profiling justifies it.

## Project format v1

A `.pfx` file is a ZIP archive containing:

- `project.json`: format/version, document name, layer metadata, stroke paths, and text objects.
- `base.png`: optional imported background image.
- `fonts/*`: imported font files referenced by text objects.

The reader validates the format identifier and restores fonts to app cache. This format is versioned so it can evolve without making older projects unreadable.

## Next milestones

1. Extract `DocumentRenderer` and `ProjectRepository` from UI code and add unit tests for serialization.
2. Implement pixel selection and raster-object transform handles; basic text repositioning/editing is now available.
3. Replace full-list undo snapshots with command history and a bounded memory budget.
4. Add masks, blend modes, crop, shapes, gradients, and layer groups.
5. Add large-canvas tile rendering and profile on low-memory devices.
6. Set up a reproducible Android SDK/Gradle build and generate a signed release APK.

## Build prerequisites

JDK 17+, Android SDK Platform 35, Android Gradle Plugin 8.7.3, Gradle 8.9, and Android Studio. The current execution environment does not have Gradle or an Android SDK installed and cannot resolve external hosts, so APK generation cannot be honestly reported as successful here. Open the project in Android Studio, sync Gradle, then use **Build → Build APK(s)**. Fix any device/build-specific issues before release.

## Interaction and memory safeguards (v0.6)
- Canvas pointer handling uses normalized document coordinates, so text movement and strokes remain resolution-independent.
- Undo/redo snapshots are capped at 80 layer states to reduce unbounded history growth. This is an interim policy; production history should use reversible commands and compact stroke deltas.
- Project ZIP import limits recognized entry sizes and total decompressed bytes, validates font entry names, and downsamples embedded base images to avoid unexpectedly large allocations.
- The current selection tool supports text-object repositioning. Raster selection, transform handles, freeform selection, and GPU/tiled rendering remain future work.

- Viewport zoom is currently a UI-level graphics transform capped at 6×; pinch interaction and drawing should be device-tested because gesture arbitration varies by Compose version/device.
- Text selection is object-level only and is limited to text elements on the active layer.

## Renderer and import safeguards (v0.6)
- Live layer previews use an isolated native Canvas save-layer, so `CLEAR`-based eraser strokes clear the selected layer's content rather than the imported base image.
- PNG export uses a separate CPU renderer on `Dispatchers.IO` and composites one temporary layer bitmap at a time.
- Image import uses a temporary file for the two-pass bounds/sampled decode instead of loading the full encoded file into a byte array. Encoded imports are capped at 256 MB and target a maximum dimension of 3072 px to reduce peak memory on low-RAM devices.


## Version 1.1.0 addition\nPer-layer masks are stored as normalized hide/restore strokes and composited with DST_IN during preview and export. The imported base bitmap has rotate, flip, crop, and resize operations. A debounced `.pfx` archive is written to app-private storage and restored on launch. Resize is capped at 12 MP.\n\n## Version 1.0.0 addition\nLayers support Normal, Multiply, Screen, Darken, and Lighten compositing modes. The selected mode is stored in `.pfx` and applied in both live preview and PNG export. Older project archives default to Normal.\n\n## Version 0.9.0 addition\nLayer names can be changed from the active-layer controls. Names are trimmed, limited to 80 characters, and cannot be empty; successful renames enter the bounded undo history.\n\n## Version 0.8.0 addition
Rectangle and ellipse strokes support an optional filled style, persisted in the project manifest. Existing archives without this field load as unfilled shapes.
