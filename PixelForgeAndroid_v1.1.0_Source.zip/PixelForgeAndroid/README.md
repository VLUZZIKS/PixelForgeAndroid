# PixelForge Android — MVP source

A native Android project for a lightweight, Photoshop-inspired image editor. Current source version: 1.1.0.

## Implemented in this iteration (v1.1.0)
- Kotlin + Jetpack Compose dark workspace
- Import images using Android's document picker
- Downsample large images on import to cap initial memory use (target max dimension 3072 px)
- Brush and eraser tools with a brush-size slider
- Vector-style line, rectangle, and ellipse tools with normalized geometry
- Optional filled rectangles and ellipses; line tool always remains a contour
- Rename layers with validation and undo support
- Per-layer blend modes: Normal, Multiply, Screen, Darken, and Lighten
- Non-destructive per-layer masks with hide/restore brush strokes and enable/disable control
- Base-image rotate 90°, horizontal/vertical flip, crop by adjustable equal margins, and resize dialog
- Select tool can drag text objects or move the imported base image
- Debounced internal `.pfx` autosave with restore on next app launch
- Resize guard: 16–8192 px per dimension and 12 MP maximum; import remains downsampled to 3072 px maximum dimension
- Blend mode settings persist in `.pfx` projects and affect live preview and PNG export
- Shape tools are preserved in project archives and rendered in PNG export
- Multiple named layers with selection, renaming, and visibility toggles
- Basic text elements rendered on the canvas and included in PNG export
- TTF/OTF font import for new text elements
- Basic text size, color palette, and rotation controls
- Save/load editable `.pfx` project archives, including imported base image and embedded fonts
- Bounded undo/redo history for document-layer operations
- Drag-to-reposition text objects with a visible selection outline
- Edit, rotate, and delete selected text objects
- Pinch-to-zoom canvas (up to 6×) with a Fit reset action
- Brush color swatches and duplicate/clear layer actions
- ZIP entry size checks and bounded base-image decode on project load
- PNG export to `Pictures/PixelForge`
- Normalized stroke coordinates so drawing scales with the imported image

## Known limitations (not production-ready)
- This is an MVP scaffold, not a Photoshop-equivalent application.
- Eraser clears pixels inside the active layer in preview and export; text and paint content currently share a layer model, so text-layer semantics are not yet as isolated as in Photoshop.
- Export currently exports the downsampled imported bitmap, not the original full-resolution source.
- Text objects can be repositioned, edited, rotated, and deleted with the Select tool, but text outlines/shadows, advanced typography, and selection of raster pixels are not implemented. Font import/build behavior still requires device testing.
- Selection is object-level for text and the imported base image; arbitrary lasso/magic-wand pixel selection and transform handles are not implemented.
- Image movement is destructive to the imported base bitmap and is not currently part of the layer-only Undo history.
- Advanced mask feathering, gradients, vector masks, tile rendering, and full device-level memory profiling are not implemented.
- Layer renaming is supported; renaming the document itself and layer groups are not implemented.
- Build and test with Android Studio before installing. No APK has been compiled or device-tested in this environment. A GitHub Actions workflow is included to build a debug APK after the source is pushed to a GitHub repository.

## Build
1. Open the `PixelForgeAndroid` folder in Android Studio.
2. Use JDK 17 and install Android SDK Platform 35.
3. Sync Gradle.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Next milestones
1. Compile, fix any SDK/Compose issues, and test on a physical Android device.
2. Implement pixel selection, raster transforms, masks, and blend modes.
3. Replace bounded snapshots with command-based history and separate text/raster layer semantics.
4. Add autosave, tile rendering, and memory/performance profiling.


See [ARCHITECTURE.md](ARCHITECTURE.md) for package boundaries, project format, rendering strategy, and milestones.

## Build APK in GitHub Actions
1. Push this project to a GitHub repository on `main` or `master`.
2. Open **Actions → Build PixelForge APK** and run the workflow (or push a commit).
3. Download the `PixelForge-debug-apk` artifact from the completed workflow run.

This CI workflow has been added to the source but has not been run from this environment. The APK artifact therefore still needs to be generated and validated.
