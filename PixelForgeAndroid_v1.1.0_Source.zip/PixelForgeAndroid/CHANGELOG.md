# Changelog

## 0.5.0 — Architecture and project files

- Split document data models, canvas geometry, and bounded image decoding into dedicated packages.
- Added `.pfx` project archive save/load, including the base image, layer stack, strokes, text settings, and cached imported fonts.
- Added UI actions for opening images, opening/saving `.pfx` projects, undo, and PNG export.
- Fixed PNG text export to use the font file stored on each text element.
- Added support for tap-sized marks in addition to dragged strokes.
- Reorganized the top action bar to horizontally scroll on narrow screens.
- Added architecture and milestone documentation.

### Validation status

Source structure and delimiter checks completed. Full Android compilation and APK generation were not possible in the current environment because neither Gradle nor the Android SDK is installed and external hosts cannot be resolved. Treat this build as unverified until synced and built in Android Studio.

## v0.6
- Added redo history alongside undo, bounded to 80 document snapshots.
- Added text-object selection and drag repositioning on the canvas.
- Added selection outline around the active text object.
- Added brush color swatches.
- Added duplicate and clear actions for the selected layer.
- Added bounds checks while reading project ZIP entries and downsampled the embedded base image on load.

- Added canvas pinch zoom/pan and Fit reset.
- Added edit, rotate, and delete actions for selected text objects.
- Added a CI workflow that builds and uploads a debug APK artifact on GitHub Actions.

- Extracted the CPU document export renderer into its own module and fixed live preview erasing to clear only within the active layer.
- Added a temporary-file image import pipeline with a 256 MB encoded-file cap and a 3072 px target dimension to lower peak RAM use.


## v0.7.0
- Added Line, Rectangle, and Ellipse outline tools.
- Added a shared shape geometry renderer for live preview and PNG export.
- Persisted shape type in `.pfx` project archives; older projects default to freehand strokes.
- Incremented Android app version to 0.7.0.
- APK compilation/device validation remains pending because Android SDK/Gradle are not available in this environment.


## 0.8.0
- Added optional fill mode for rectangle and ellipse tools.
- Kept line tool as an outline-only tool.
- Saved fill style in `.pfx` project archives with backwards-compatible defaults.
- Applied the same fill behavior to live preview and PNG export.
- Incremented Android app version to 0.8.0.
- Android compilation and device validation are still pending.


## 0.9.0
- Added layer renaming through the selected-layer controls.
- Added a single-line layer-name dialog with an 80-character limit and whitespace trimming.
- Empty layer names are rejected; renames are recorded in undo history.
- Incremented Android app version to 0.9.0.
- Android compilation and device validation remain pending.


## 1.0.0
- Added per-layer blend modes: Normal, Multiply, Screen, Darken, and Lighten.
- Applied blend modes in both the live canvas preview and PNG export.
- Persisted blend modes in `.pfx` archives; older projects default to Normal.
- Fixed live preview so filled rectangles and ellipses use fill rendering, matching export.
- Incremented Android app version to 1.0.0 (versionCode 10).
- Full Android compilation and device testing remain pending.


## 1.1.0
- Added per-layer nondestructive mask strokes with hide/restore modes and mask enable/disable.
- Saved and restored mask data in `.pfx` project archives.
- Added base-image rotate 90°, horizontal/vertical flip, adjustable-margin crop, and dimension-based resize.
- Added object selection behavior to drag text or move the imported base image.
- Added debounced internal autosave and startup restoration, with atomic temporary-file writes where supported.
- Added resize limits (maximum 12 megapixels) to reduce out-of-memory risk.
- Added/updated CI documentation; APK build still requires a successful GitHub Actions or Android Studio build.
