package com.pixelforge.editor.model

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color

/** A normalized brush path. Coordinates are in 0..1 document space, independent of viewport size. */
data class PaintStroke(
    val points: List<Offset>,
    val color: Color,
    val width: Float,
    val eraser: Boolean = false,
    val shape: String = "freehand",
    val filled: Boolean = false
)

/** Text content stored in document coordinates. fontPath points to a cached imported font file. */
data class TextElement(
    val text: String,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val size: Float = 48f,
    val color: Color = Color(0xFF111111),
    val fontPath: String? = null,
    val rotation: Float = 0f
)

/** A compositing unit. The list order is the layer stack order. */
data class EditorLayer(
    val id: Int,
    val name: String,
    val visible: Boolean = true,
    val opacity: Float = 1f,
    val strokes: List<PaintStroke> = emptyList(),
    val textElements: List<TextElement> = emptyList(),
    val blendMode: String = "normal",
    val maskStrokes: List<PaintStroke> = emptyList(),
    val maskEnabled: Boolean = true
)
