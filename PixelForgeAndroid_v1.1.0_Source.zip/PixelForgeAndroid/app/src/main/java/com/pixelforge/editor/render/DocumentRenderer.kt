package com.pixelforge.editor.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Typeface
import com.pixelforge.editor.model.EditorLayer

private fun blendXfermode(name: String): PorterDuffXfermode? = when (name) {
    "multiply" -> PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
    "screen" -> PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    "darken" -> PorterDuffXfermode(PorterDuff.Mode.DARKEN)
    "lighten" -> PorterDuffXfermode(PorterDuff.Mode.LIGHTEN)
    else -> null
}

private fun buildMaskBitmap(layer: EditorLayer, width: Int, height: Int): Bitmap {
    val mask = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
    val canvas = Canvas(mask)
    canvas.drawColor(android.graphics.Color.WHITE)
    val bounds = android.graphics.RectF(0f, 0f, width.toFloat(), height.toFloat())
    layer.maskStrokes.forEach { stroke ->
        if (stroke.points.isEmpty()) return@forEach
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            strokeWidth = stroke.width * ((width / 1000f + height / 700f) / 2f)
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            if (stroke.eraser) xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        drawStrokeGeometry(canvas, stroke.points, bounds, paint, stroke.shape)
    }
    return mask
}

private fun drawStrokeGeometry(
    canvas: Canvas,
    points: List<androidx.compose.ui.geometry.Offset>,
    rect: android.graphics.RectF,
    paint: Paint,
    shape: String
) {
    if (points.isEmpty()) return
    val first = points.first()
    val last = points.last()
    val x1 = rect.left + first.x * rect.width()
    val y1 = rect.top + first.y * rect.height()
    val x2 = rect.left + last.x * rect.width()
    val y2 = rect.top + last.y * rect.height()
    when (shape) {
        "line" -> canvas.drawLine(x1, y1, x2, y2, paint)
        "rectangle" -> {
            val left = minOf(x1, x2); val top = minOf(y1, y2)
            val right = maxOf(x1, x2); val bottom = maxOf(y1, y2)
            if (paint.style == Paint.Style.FILL) canvas.drawRect(left, top, right, bottom, paint)
            else canvas.drawRect(left, top, right, bottom, paint)
        }
        "ellipse" -> canvas.drawOval(minOf(x1, x2), minOf(y1, y2), maxOf(x1, x2), maxOf(y1, y2), paint)
        else -> {
            if (points.size == 1) canvas.drawCircle(x1, y1, paint.strokeWidth / 2f, paint)
            else {
                val path = Path().apply {
                    moveTo(x1, y1)
                    points.drop(1).forEach { lineTo(rect.left + it.x * rect.width(), rect.top + it.y * rect.height()) }
                }
                canvas.drawPath(path, paint)
            }
        }
    }
}

/**
 * CPU export renderer. Renders each editable layer to a transparent intermediate bitmap so an
 * eraser clears pixels on its own layer rather than removing the imported background.
 * Call from a worker dispatcher for non-trivial documents.
 */
fun renderDocumentBitmap(baseBitmap: Bitmap?, layers: List<EditorLayer>, width: Int, height: Int): Bitmap {
    require(width > 0 && height > 0) { "Invalid output dimensions" }
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val outputCanvas = Canvas(output)
    outputCanvas.drawColor(android.graphics.Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
    if (baseBitmap != null) outputCanvas.drawBitmap(baseBitmap, null, android.graphics.Rect(0, 0, width, height), null)

    layers.filter { it.visible }.forEach layerLoop@ { layer ->
        val layerBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        try {
            val layerCanvas = Canvas(layerBitmap)
            layer.strokes.forEach strokeLoop@ { stroke ->
                if (stroke.points.isEmpty()) return@strokeLoop
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = stroke.color.toArgbInt()
                    strokeWidth = stroke.width * ((width / 1000f + height / 700f) / 2f)
                    style = if (stroke.filled && stroke.shape in setOf("rectangle", "ellipse")) Paint.Style.FILL else Paint.Style.STROKE
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                    if (stroke.eraser) xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                }
                drawStrokeGeometry(layerCanvas, stroke.points, android.graphics.RectF(0f, 0f, width.toFloat(), height.toFloat()), paint, stroke.shape)
            }
            // Text objects remain editable and are composited above raster/eraser strokes.
            layer.textElements.forEach { element ->
                val font = element.fontPath?.let { path -> runCatching { Typeface.createFromFile(path) }.getOrNull() }
                    ?: Typeface.DEFAULT
                val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = element.color.toArgbInt()
                    textSize = element.size * ((width / 1000f + height / 700f) / 2f)
                    typeface = font
                }
                val x = element.x * width
                val y = element.y * height
                layerCanvas.save()
                layerCanvas.rotate(element.rotation, x, y)
                layerCanvas.drawText(element.text, x, y, textPaint)
                layerCanvas.restore()
            }
            if (layer.maskEnabled && layer.maskStrokes.isNotEmpty()) {
                val mask = buildMaskBitmap(layer, width, height)
                try {
                    layerCanvas.drawBitmap(mask, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
                    })
                } finally {
                    mask.recycle()
                }
            }
            val alphaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                alpha = (layer.opacity.coerceIn(0f, 1f) * 255).toInt()
                xfermode = blendXfermode(layer.blendMode)
            }
            outputCanvas.drawBitmap(layerBitmap, 0f, 0f, alphaPaint)
        } finally {
            layerBitmap.recycle()
        }
    }
    return output
}

/** Draws one editable layer into the live viewport. saveLayer isolates CLEAR-based eraser strokes. */
fun drawLayerPreview(
    canvas: Canvas,
    layer: EditorLayer,
    rect: ContentRect,
    widthScale: Float,
    heightScale: Float,
    selectedTextIndex: Int = -1,
    showSelection: Boolean = false
) {
    val compositingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        alpha = (layer.opacity.coerceIn(0f, 1f) * 255).toInt()
        xfermode = blendXfermode(layer.blendMode)
    }
    val bounds = android.graphics.RectF(rect.left, rect.top, rect.left + rect.width, rect.top + rect.height)
    canvas.saveLayer(bounds, compositingPaint)
    try {
        layer.strokes.forEach strokeLoop@ { stroke ->
            if (stroke.points.isEmpty()) return@strokeLoop
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = stroke.color.toArgbInt()
                strokeWidth = stroke.width * ((widthScale / 1000f + heightScale / 700f) / 2f)
                style = if (stroke.filled && stroke.shape in setOf("rectangle", "ellipse")) Paint.Style.FILL else Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                if (stroke.eraser) xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            }
            drawStrokeGeometry(
                canvas, stroke.points,
                android.graphics.RectF(rect.left, rect.top, rect.left + rect.width, rect.top + rect.height),
                paint, stroke.shape
            )
        }
        layer.textElements.forEachIndexed { index, element ->
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = element.color.toArgbInt()
                textSize = element.size * ((widthScale / 1000f + heightScale / 700f) / 2f)
                typeface = element.fontPath?.let { runCatching { Typeface.createFromFile(it) }.getOrNull() }
                    ?: Typeface.DEFAULT
            }
            val x = rect.left + element.x * rect.width
            val y = rect.top + element.y * rect.height
            canvas.save()
            canvas.rotate(element.rotation, x, y)
            canvas.drawText(element.text, x, y, textPaint)
            if (showSelection && index == selectedTextIndex) {
                val textBounds = android.graphics.Rect()
                textPaint.getTextBounds(element.text, 0, element.text.length, textBounds)
                val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.rgb(80, 160, 255)
                    style = Paint.Style.STROKE
                    strokeWidth = 2f
                    pathEffect = android.graphics.DashPathEffect(floatArrayOf(8f, 5f), 0f)
                }
                canvas.drawRect(x + textBounds.left - 6f, y + textBounds.top - 6f,
                    x + textBounds.right + 6f, y + textBounds.bottom + 6f, outline)
            }
            canvas.restore()
        }
        if (layer.maskEnabled && layer.maskStrokes.isNotEmpty()) {
            val maskWidth = rect.width.toInt().coerceAtLeast(1)
            val maskHeight = rect.height.toInt().coerceAtLeast(1)
            val mask = buildMaskBitmap(layer, maskWidth, maskHeight)
            try {
                canvas.drawBitmap(
                    mask,
                    null,
                    android.graphics.RectF(rect.left, rect.top, rect.left + rect.width, rect.top + rect.height),
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
                )
            } finally {
                mask.recycle()
            }
        }
    } finally {
        canvas.restore()
    }
}


/** Draws an in-progress line or outline shape in normalized document coordinates. */
fun drawShapePreview(
    canvas: Canvas,
    points: List<androidx.compose.ui.geometry.Offset>,
    rect: ContentRect,
    color: androidx.compose.ui.graphics.Color,
    width: Float,
    shape: String,
    filled: Boolean = false
) {
    if (points.isEmpty()) return
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color.toArgbInt()
        strokeWidth = width * ((rect.width / 1000f + rect.height / 700f) / 2f)
        style = if (filled && shape in setOf("rectangle", "ellipse")) Paint.Style.FILL else Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    drawStrokeGeometry(canvas, points, android.graphics.RectF(rect.left, rect.top, rect.left + rect.width, rect.top + rect.height), paint, shape)
}
