package com.pixelforge.editor.io

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.InputStream
import kotlin.math.max

/**
 * Copies the encoded image to a temporary file, then performs bounds and sampled decode passes.
 * This avoids retaining a second full-size byte array in memory on low-RAM devices.
 */
fun decodeDownsampled(input: InputStream, maxDimension: Int): Bitmap? {
    require(maxDimension >= 1) { "maxDimension must be positive" }
    val temp = File.createTempFile("pixelforge-import-", ".img")
    try {
        input.use { source ->
            temp.outputStream().buffered().use { sink ->
                val buffer = ByteArray(32 * 1024)
                var total = 0L
                while (true) {
                    val count = source.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= 256L * 1024 * 1024) { "Image file is larger than the 256 MB import limit" }
                    sink.write(buffer, 0, count)
                }
            }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(temp.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDimension) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeFile(temp.absolutePath, options)
    } finally {
        temp.delete()
    }
}
