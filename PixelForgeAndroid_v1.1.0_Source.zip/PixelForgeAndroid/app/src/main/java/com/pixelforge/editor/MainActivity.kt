package com.pixelforge.editor

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.pixelforge.editor.model.EditorLayer
import com.pixelforge.editor.model.PaintStroke
import com.pixelforge.editor.model.TextElement
import com.pixelforge.editor.render.canvasContentRect
import com.pixelforge.editor.render.drawNormalizedStroke
import com.pixelforge.editor.render.drawLayerPreview
import com.pixelforge.editor.render.drawShapePreview
import com.pixelforge.editor.render.toArgbInt
import com.pixelforge.editor.io.decodeDownsampled

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PixelForgeApp() }
    }
}

@Composable
private fun PixelForgeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var documentName by remember { mutableStateOf("Untitled project") }
    var tool by remember { mutableStateOf("Brush") }
    var brushSize by remember { mutableFloatStateOf(12f) }
    var brushColor by remember { mutableStateOf(Color(0xFF111111)) }
    var filledShapes by remember { mutableStateOf(false) }
    var layers by remember { mutableStateOf(listOf(EditorLayer(1, "Paint layer 1"))) }
    var selectedLayerId by remember { mutableIntStateOf(1) }
    var nextLayerId by remember { mutableIntStateOf(2) }
    var activePoints by remember { mutableStateOf(listOf<Offset>()) }
    var undoHistory by remember { mutableStateOf(listOf<List<EditorLayer>>()) }
    var redoHistory by remember { mutableStateOf(listOf<List<EditorLayer>>()) }
    var status by remember { mutableStateOf("Ready") }
    var showTextDialog by remember { mutableStateOf(false) }
    var showRenameLayerDialog by remember { mutableStateOf(false) }
    var renameLayerValue by remember { mutableStateOf("") }
    var showResizeDialog by remember { mutableStateOf(false) }
    var resizeWidthValue by remember { mutableStateOf("1600") }
    var resizeHeightValue by remember { mutableStateOf("1120") }
    var cropPercent by remember { mutableFloatStateOf(10f) }
    var imageDragOffset by remember { mutableStateOf(Offset.Zero) }
    var movingBaseImage by remember { mutableStateOf(false) }
    var maskRestoreMode by remember { mutableStateOf(false) }
    var autosaveRestored by remember { mutableStateOf(false) }
    var editExistingText by remember { mutableStateOf(false) }
    var textValue by remember { mutableStateOf("") }
    var selectedTextIndex by remember { mutableIntStateOf(-1) }
    var importedTypeface by remember { mutableStateOf<Typeface?>(null) }
    var importedFontPath by remember { mutableStateOf<String?>(null) }
    var importedFontName by remember { mutableStateOf<String?>(null) }
    var textSize by remember { mutableFloatStateOf(48f) }
    var textRotation by remember { mutableFloatStateOf(0f) }
    var textColor by remember { mutableStateOf(Color(0xFF111111)) }
    var canvasZoom by remember { mutableFloatStateOf(1f) }
    var canvasPanX by remember { mutableFloatStateOf(0f) }
    var canvasPanY by remember { mutableFloatStateOf(0f) }

    val fontLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val typeface = withContext(Dispatchers.IO) {
                try {
                    val file = java.io.File(context.cacheDir, "imported_font_${System.currentTimeMillis()}.ttf")
                    context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use(input::copyTo) }
                    importedFontPath = file.absolutePath
                    Typeface.createFromFile(file)
                } catch (_: Exception) { null }
            }
            if (typeface != null) {
                importedTypeface = typeface
                importedFontName = "Imported font"
                status = "Font imported for new text"
            } else status = "Could not load this font"
        }
    }

    val selectedLayer = layers.firstOrNull { it.id == selectedLayerId }
    val currentLayersState = rememberUpdatedState(layers)
    val currentSelectedLayerIdState = rememberUpdatedState(selectedLayerId)

    fun transformSourceBitmap(operation: String) {
        val original = sourceBitmap
        if (original == null) {
            status = "Open an image first"
            return
        }
        runCatching {
            val transformed = when (operation) {
                "rotate" -> {
                    val matrix = Matrix().apply { postRotate(90f) }
                    Bitmap.createBitmap(original, 0, 0, original.width, original.height, matrix, true)
                }
                "flipH" -> {
                    val matrix = Matrix().apply { postScale(-1f, 1f, original.width / 2f, original.height / 2f) }
                    Bitmap.createBitmap(original, 0, 0, original.width, original.height, matrix, true)
                }
                "flipV" -> {
                    val matrix = Matrix().apply { postScale(1f, -1f, original.width / 2f, original.height / 2f) }
                    Bitmap.createBitmap(original, 0, 0, original.width, original.height, matrix, true)
                }
                else -> original
            }
            if (transformed !== original) {
                sourceBitmap = transformed
                if (transformed !== original) original.recycle()
                status = when (operation) {
                    "rotate" -> "Image rotated 90°"
                    "flipH" -> "Image flipped horizontally"
                    else -> "Image flipped vertically"
                }
            }
        }.onFailure { status = "Image transform failed: ${it.message ?: "unknown error"}" }
    }

    fun cropSourceBitmap(percent: Float) {
        val original = sourceBitmap ?: run { status = "Open an image first"; return }
        val marginX = (original.width * percent / 100f).toInt().coerceIn(0, original.width / 4)
        val marginY = (original.height * percent / 100f).toInt().coerceIn(0, original.height / 4)
        val newWidth = original.width - marginX * 2
        val newHeight = original.height - marginY * 2
        if (newWidth < 16 || newHeight < 16) { status = "Crop area is too small"; return }
        runCatching {
            val cropped = Bitmap.createBitmap(original, marginX, marginY, newWidth, newHeight)
            sourceBitmap = cropped
            if (cropped !== original) original.recycle()
            status = "Cropped ${newWidth}×${newHeight}"
        }.onFailure { status = "Crop failed" }
    }

    fun resizeSourceBitmap(width: Int, height: Int) {
        val original = sourceBitmap ?: run { status = "Open an image first"; return }
        if (width !in 16..8192 || height !in 16..8192 || width.toLong() * height > 12_000_000L) {
            status = "Size must be 16–8192 px and at most 12 MP"
            return
        }
        runCatching {
            val resized = Bitmap.createScaledBitmap(original, width, height, true)
            sourceBitmap = resized
            if (resized !== original) original.recycle()
            status = "Resized to ${width}×${height}"
            showResizeDialog = false
        }.onFailure { status = "Resize failed: ${it.message ?: "unknown error"}" }
    }

    LaunchedEffect(Unit) {
        val autosaveFile = java.io.File(context.filesDir, "pixelforge_autosave.pfx")
        val restored = withContext(Dispatchers.IO) {
            if (autosaveFile.isFile && autosaveFile.length() in 1..(160L * 1024 * 1024)) {
                runCatching { com.pixelforge.editor.io.readProjectFromFile(context, autosaveFile) }.getOrNull()
            } else null
        }
        if (restored != null) {
            sourceBitmap = restored.baseBitmap
            documentName = restored.name
            layers = restored.layers
            selectedLayerId = layers.last().id
            nextLayerId = (layers.maxOfOrNull { it.id } ?: 0) + 1
            status = "Autosave restored"
        }
        autosaveRestored = true
    }

    LaunchedEffect(sourceBitmap, layers, documentName, autosaveRestored) {
        if (!autosaveRestored) return@LaunchedEffect
        delay(1200)
        val snapshotBitmap = sourceBitmap
        val snapshotLayers = layers
        val snapshotName = documentName
        withContext(Dispatchers.IO) {
            runCatching {
                com.pixelforge.editor.io.writeProjectToFile(
                    context,
                    java.io.File(context.filesDir, "pixelforge_autosave.pfx"),
                    snapshotName,
                    snapshotBitmap,
                    snapshotLayers
                )
            }
        }
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            status = "Opening image…"
            val decoded = withContext(Dispatchers.IO) {
                runCatching { context.contentResolver.openInputStream(uri)?.use { decodeDownsampled(it, 3072) } }.getOrNull()
            }
            if (decoded != null) {
                sourceBitmap = decoded
                documentName = "Untitled_${decoded.width}x${decoded.height}"
                layers = listOf(EditorLayer(1, "Paint layer 1"))
                selectedLayerId = 1
                nextLayerId = 2
                undoHistory = emptyList()
                status = "Image opened"
            } else status = "Could not open image"
        }
    }

    val saveProjectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) {
            val snapshotName = documentName
            val snapshotBitmap = sourceBitmap
            val snapshotLayers = layers
            scope.launch {
                status = "Saving project…"
                val result = withContext(Dispatchers.IO) {
                    runCatching { com.pixelforge.editor.io.writeProject(context, uri, snapshotName, snapshotBitmap, snapshotLayers) }.isSuccess
                }
                status = if (result) "Project saved" else "Project save failed"
            }
        }
    }

    val openProjectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            status = "Opening project…"
            val loaded = withContext(Dispatchers.IO) {
                runCatching { com.pixelforge.editor.io.readProject(context, uri) }.getOrNull()
            }
            if (loaded != null) {
                sourceBitmap = loaded.baseBitmap
                documentName = loaded.name
                layers = loaded.layers
                selectedLayerId = layers.last().id
                nextLayerId = (layers.maxOfOrNull { it.id } ?: 0) + 1
                undoHistory = emptyList()
                status = "Project opened"
            } else status = "Could not open project"
        }
    }

    fun recordUndo() {
        undoHistory = (undoHistory + listOf(layers)).takeLast(80)
        redoHistory = emptyList()
    }

    fun addLayer() {
        recordUndo()
        val layer = EditorLayer(nextLayerId, "Paint layer $nextLayerId")
        layers = layers + layer
        selectedLayerId = layer.id
        nextLayerId++
        status = "Layer added"
    }

    fun undo() {
        if (undoHistory.isNotEmpty()) {
            redoHistory = (redoHistory + listOf(layers)).takeLast(80)
            layers = undoHistory.last()
            undoHistory = undoHistory.dropLast(1)
            if (layers.none { it.id == selectedLayerId }) selectedLayerId = layers.lastOrNull()?.id ?: 1
            status = "Undo"
        } else status = "Nothing to undo"
    }

    fun redo() {
        if (redoHistory.isNotEmpty()) {
            undoHistory = (undoHistory + listOf(layers)).takeLast(80)
            layers = redoHistory.last()
            redoHistory = redoHistory.dropLast(1)
            if (layers.none { it.id == selectedLayerId }) selectedLayerId = layers.lastOrNull()?.id ?: 1
            status = "Redo"
        } else status = "Nothing to redo"
    }

    fun toggleLayer(layerId: Int) {
        recordUndo()
        layers = layers.map { if (it.id == layerId) it.copy(visible = !it.visible) else it }
    }

    fun setLayerOpacity(layerId: Int, opacity: Float) {
        layers = layers.map { if (it.id == layerId) it.copy(opacity = opacity.coerceIn(0f, 1f)) else it }
    }

    fun setLayerBlendMode(layerId: Int, mode: String) {
        val current = layers.firstOrNull { it.id == layerId } ?: return
        if (current.blendMode == mode) return
        recordUndo()
        layers = layers.map { if (it.id == layerId) it.copy(blendMode = mode) else it }
        status = "Blend mode: ${mode.replaceFirstChar { it.uppercase() }}"
    }

    fun duplicateSelectedLayer() {
        val current = layers.firstOrNull { it.id == selectedLayerId } ?: return
        recordUndo()
        val duplicate = current.copy(id = nextLayerId, name = "${current.name} copy")
        val insertAt = (layers.indexOf(current) + 1).coerceAtMost(layers.size)
        layers = layers.toMutableList().apply { add(insertAt, duplicate) }
        selectedLayerId = duplicate.id
        nextLayerId++
        status = "Layer duplicated"
    }

    fun deleteSelectedText() {
        val layer = layers.firstOrNull { it.id == selectedLayerId } ?: return
        if (selectedTextIndex !in layer.textElements.indices) return
        recordUndo()
        layers = layers.map { current ->
            if (current.id == selectedLayerId) current.copy(
                textElements = current.textElements.filterIndexed { index, _ -> index != selectedTextIndex }
            ) else current
        }
        selectedTextIndex = -1
        status = "Text object deleted"
    }

    fun rotateSelectedText() {
        val layer = layers.firstOrNull { it.id == selectedLayerId } ?: return
        if (selectedTextIndex !in layer.textElements.indices) return
        recordUndo()
        layers = layers.map { current ->
            if (current.id == selectedLayerId) current.copy(textElements = current.textElements.mapIndexed { index, element ->
                if (index == selectedTextIndex) element.copy(rotation = (element.rotation + 15f) % 360f) else element
            }) else current
        }
        status = "Text rotated"
    }

    fun clearSelectedLayer() {
        val current = layers.firstOrNull { it.id == selectedLayerId } ?: return
        if (current.strokes.isEmpty() && current.textElements.isEmpty() && current.maskStrokes.isEmpty()) return
        recordUndo()
        layers = layers.map { if (it.id == selectedLayerId) it.copy(strokes = emptyList(), textElements = emptyList(), maskStrokes = emptyList()) else it }
        selectedTextIndex = -1
        status = "Layer cleared"
    }

    fun deleteSelectedLayer() {
        if (layers.size <= 1) {
            status = "At least one paint layer is required"
            return
        }
        recordUndo()
        layers = layers.filterNot { it.id == selectedLayerId }
        selectedLayerId = layers.last().id
        status = "Layer deleted"
    }

    fun moveLayer(layerId: Int, direction: Int) {
        val index = layers.indexOfFirst { it.id == layerId }
        val target = index + direction
        if (index < 0 || target !in layers.indices) return
        recordUndo()
        val copy = layers.toMutableList()
        val temp = copy[index]
        copy[index] = copy[target]
        copy[target] = temp
        layers = copy
        status = "Layer order changed"
    }

    fun exportPng() {
        scope.launch {
            status = "Exporting PNG…"
            val snapshotLayers = layers
            val base = sourceBitmap
            val success = withContext(Dispatchers.IO) {
                runCatching {
                    val output = com.pixelforge.editor.render.renderDocumentBitmap(
                        baseBitmap = base,
                        layers = snapshotLayers,
                        width = base?.width ?: 1600,
                        height = base?.height ?: 1120
                    )
                    try {
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "PixelForge_${System.currentTimeMillis()}.png")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PixelForge")
                        }
                        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        uri?.let { target ->
                            context.contentResolver.openOutputStream(target)?.use { output.compress(Bitmap.CompressFormat.PNG, 100, it) } ?: false
                        } ?: false
                    } finally {
                        output.recycle()
                    }
                }.getOrDefault(false)
            }
            status = if (success) "PNG saved to Pictures/PixelForge" else "Export failed"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF79A9FF),
        background = Color(0xFF17191D),
        surface = Color(0xFF24272E)
    )) {
        Column(Modifier.fillMaxSize().background(Color(0xFF17191D)).padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PIXELFORGE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
                    Text(documentName, color = Color.LightGray, fontSize = 11.sp)
                }
                Text(status, color = Color(0xFFB9C0CB), fontSize = 10.sp, maxLines = 1)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { openLauncher.launch(arrayOf("image/*")) }) { Text("Image") }
                TextButton(onClick = { openProjectLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) { Text("Open .pfx") }
                TextButton(onClick = { saveProjectLauncher.launch("${documentName.replace(Regex("[^A-Za-z0-9_-]"), "_")}.pfx") }) { Text("Save project") }
                TextButton(onClick = { undo() }) { Text("Undo") }
                TextButton(onClick = { redo() }) { Text("Redo") }
                TextButton(onClick = { canvasZoom = 1f; canvasPanX = 0f; canvasPanY = 0f }) { Text("Fit") }
                Button(onClick = { exportPng() }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) { Text("PNG") }
            }
            Spacer(Modifier.height(4.dp))
            Text("Canvas zoom ${(canvasZoom * 100).toInt()}% · pinch to zoom · Fit to reset", color = Color(0xFF9CA5B3), fontSize = 10.sp)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { transformSourceBitmap("rotate") }) { Text("Rotate 90°") }
                TextButton(onClick = { transformSourceBitmap("flipH") }) { Text("Flip H") }
                TextButton(onClick = { transformSourceBitmap("flipV") }) { Text("Flip V") }
                TextButton(onClick = { cropPercent = 10f; status = "Crop uses equal margins on all sides"; }) { Text("Crop settings") }
                TextButton(onClick = { showResizeDialog = true; resizeWidthValue = (sourceBitmap?.width ?: 1600).toString(); resizeHeightValue = (sourceBitmap?.height ?: 1120).toString() }) { Text("Resize") }
                TextButton(onClick = { cropSourceBitmap(cropPercent) }) { Text("Crop") }
            }
            if (tool == "Select") {
                Text("Select: drag text to move it, or drag the image when no text is selected.", color = Color(0xFF9CA5B3), fontSize = 10.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("Brush", "Eraser", "Line", "Rect", "Ellipse", "Text", "Select", "Mask").forEach { item ->
                    FilterChip(
                        selected = tool == item,
                        onClick = {
                            tool = item
                            if (item == "Text") { editExistingText = false; showTextDialog = true }
                            if (item == "Select") status = "Select and drag text or the base image"
                            if (item == "Mask") status = "Mask mode: drag to hide pixels; enable Restore to paint them back"
                        },
                        label = { Text(item, fontSize = 12.sp) }
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Crop margin ${cropPercent.toInt()}%", color = Color.LightGray, fontSize = 10.sp)
                Slider(value = cropPercent, onValueChange = { cropPercent = it }, valueRange = 0f..20f, modifier = Modifier.weight(1f))
            }
            if (tool == "Mask") {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(checked = maskRestoreMode, onCheckedChange = { maskRestoreMode = it })
                    Text(if (maskRestoreMode) "Restore mask" else "Erase mask", color = Color.LightGray, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    selectedLayer?.let { layer ->
                        FilterChip(
                            selected = layer.maskEnabled,
                            onClick = {
                                recordUndo()
                                layers = layers.map { if (it.id == layer.id) it.copy(maskEnabled = !it.maskEnabled) else it }
                                status = if (layer.maskEnabled) "Layer mask disabled" else "Layer mask enabled"
                            },
                            label = { Text(if (layer.maskEnabled) "Mask on" else "Mask off", fontSize = 11.sp) }
                        )
                    }
                }
            }
            if (tool in listOf("Rect", "Ellipse")) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(checked = filledShapes, onCheckedChange = { filledShapes = it })
                    Text("Filled shape", color = Color.LightGray, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text("Outline uses brush size", color = Color(0xFF9CA5B3), fontSize = 10.sp)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Font: ${importedFontName ?: "System"}", color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { fontLauncher.launch(arrayOf("font/ttf", "font/otf", "application/octet-stream", "*/*")) }) { Text("Import TTF/OTF") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Color", color = Color.LightGray, fontSize = 11.sp)
                listOf(Color(0xFF111111), Color.White, Color(0xFFDF3D3D), Color(0xFF3478F6), Color(0xFF25A56A), Color(0xFFFFC247)).forEach { c ->
                    Button(
                        onClick = { brushColor = c },
                        colors = ButtonDefaults.buttonColors(containerColor = c, contentColor = if (c == Color.White) Color.Black else Color.White),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(25.dp)
                    ) { Text(if (brushColor == c) "✓" else "", fontSize = 10.sp) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Size", color = Color.LightGray, fontSize = 12.sp)
                Slider(value = brushSize, onValueChange = { brushSize = it }, valueRange = 1f..48f, modifier = Modifier.weight(1f))
                Text("${brushSize.toInt()} px", color = Color.White, fontSize = 12.sp)
            }

            if (tool == "Select" && selectedTextIndex >= 0 && selectedLayer?.textElements?.getOrNull(selectedTextIndex) != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = {
                        val selectedText = selectedLayer!!.textElements[selectedTextIndex]
                        textValue = selectedText.text
                        textSize = selectedText.size
                        textColor = selectedText.color
                        textRotation = selectedText.rotation
                        importedFontPath = selectedText.fontPath
                        importedTypeface = selectedText.fontPath?.let { runCatching { Typeface.createFromFile(it) }.getOrNull() }
                        editExistingText = true
                        showTextDialog = true
                    }) { Text("Edit text") }
                    TextButton(onClick = { rotateSelectedText() }) { Text("Rotate +15°") }
                    TextButton(onClick = { deleteSelectedText() }) { Text("Delete text") }
                }
            }
            if (tool == "Text") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Text size", color = Color.LightGray, fontSize = 11.sp)
                    Slider(value = textSize, onValueChange = { textSize = it }, valueRange = 16f..120f, modifier = Modifier.weight(1f))
                    Text("${textSize.toInt()}", color = Color.White, fontSize = 11.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(Color(0xFF111111), Color.White, Color(0xFFDF3D3D), Color(0xFF3478F6), Color(0xFF25A56A)).forEach { c ->
                        Button(
                            onClick = { textColor = c },
                            colors = ButtonDefaults.buttonColors(containerColor = c, contentColor = if (c == Color.White) Color.Black else Color.White),
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(28.dp)
                        ) { Text(if (textColor == c) "✓" else "", fontSize = 10.sp) }
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { textRotation = (textRotation + 15f) % 360f }) { Text("Rotate +15°") }
                }
            }
            Box(
                Modifier.weight(1f).fillMaxWidth()
                    .background(Color(0xFF2A2D33), RoundedCornerShape(10.dp))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    Modifier.fillMaxSize()
                        .clipToBounds()
                        .graphicsLayer {
                            scaleX = canvasZoom
                            scaleY = canvasZoom
                            translationX = canvasPanX
                            translationY = canvasPanY
                        }
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoomChange, _ ->
                                canvasZoom = (canvasZoom * zoomChange).coerceIn(1f, 6f)
                                if (canvasZoom > 1f) {
                                    canvasPanX += pan.x
                                    canvasPanY += pan.y
                                } else {
                                    canvasPanX = 0f
                                    canvasPanY = 0f
                                }
                            }
                        }
                        .pointerInput(tool, brushSize, brushColor, selectedLayerId, sourceBitmap, maskRestoreMode) {
                        var selectionUndoSaved = false
                        detectDragGestures(
                            onDragStart = { p ->
                                selectionUndoSaved = false
                                val rect = canvasContentRect(size.width.toFloat(), size.height.toFloat(), sourceBitmap?.width, sourceBitmap?.height)
                                if (tool in listOf("Brush", "Eraser", "Line", "Rect", "Ellipse", "Mask")) {
                                    activePoints = listOf(Offset(
                                        ((p.x - rect.left) / rect.width).coerceIn(0f, 1f),
                                        ((p.y - rect.top) / rect.height).coerceIn(0f, 1f)
                                    ))
                                } else if (tool == "Select") {
                                    val activeLayer = currentLayersState.value.firstOrNull { it.id == currentSelectedLayerIdState.value }
                                    val nearest = activeLayer?.textElements?.mapIndexed { index, element ->
                                        val x = rect.left + element.x * rect.width
                                        val y = rect.top + element.y * rect.height
                                        index to kotlin.math.hypot((p.x - x).toDouble(), (p.y - y).toDouble()).toFloat()
                                    }?.minByOrNull { it.second }
                                    selectedTextIndex = nearest?.takeIf { it.second < 52f }?.first ?: -1
                                    movingBaseImage = selectedTextIndex < 0 && sourceBitmap != null
                                    imageDragOffset = Offset.Zero
                                    status = if (selectedTextIndex >= 0) "Drag to move text" else if (movingBaseImage) "Drag to move image" else "No object to move"
                                }
                            },
                            onDrag = { change, _ ->
                                val rect = canvasContentRect(size.width.toFloat(), size.height.toFloat(), sourceBitmap?.width, sourceBitmap?.height)
                                val p = change.position
                                if (tool in listOf("Brush", "Eraser", "Line", "Rect", "Ellipse", "Mask")) {
                                    val point = Offset(
                                        ((p.x - rect.left) / rect.width).coerceIn(0f, 1f),
                                        ((p.y - rect.top) / rect.height).coerceIn(0f, 1f)
                                    )
                                    activePoints = if (tool in listOf("Line", "Rect", "Ellipse")) {
                                        listOf(activePoints.firstOrNull() ?: point, point)
                                    } else activePoints + point
                                } else if (tool == "Select" && selectedTextIndex >= 0) {
                                    if (!selectionUndoSaved) {
                                        undoHistory = (undoHistory + listOf(currentLayersState.value)).takeLast(80)
                                        redoHistory = emptyList()
                                        selectionUndoSaved = true
                                    }
                                    val targetId = currentSelectedLayerIdState.value
                                    val nx = ((p.x - rect.left) / rect.width).coerceIn(0f, 1f)
                                    val ny = ((p.y - rect.top) / rect.height).coerceIn(0f, 1f)
                                    layers = currentLayersState.value.map { layer ->
                                        if (layer.id == targetId && selectedTextIndex in layer.textElements.indices) {
                                            layer.copy(textElements = layer.textElements.mapIndexed { index, item ->
                                                if (index == selectedTextIndex) item.copy(x = nx, y = ny) else item
                                            })
                                        } else layer
                                    }
                                } else if (tool == "Select" && movingBaseImage) {
                                    imageDragOffset += change.position - change.previousPosition
                                }
                            },
                            onDragEnd = {
                                if (tool == "Select" && movingBaseImage && imageDragOffset != Offset.Zero) {
                                    val original = sourceBitmap
                                    if (original != null) {
                                        val rect = canvasContentRect(size.width.toFloat(), size.height.toFloat(), original.width, original.height)
                                        val dx = imageDragOffset.x * original.width / rect.width.coerceAtLeast(1f)
                                        val dy = imageDragOffset.y * original.height / rect.height.coerceAtLeast(1f)
                                        runCatching {
                                            val moved = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
                                            val movedCanvas = android.graphics.Canvas(moved)
                                            movedCanvas.drawColor(android.graphics.Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR)
                                            movedCanvas.drawBitmap(original, dx, dy, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG))
                                            sourceBitmap = moved
                                            original.recycle()
                                            status = "Image moved"
                                        }.onFailure { status = "Image move failed" }
                                    }
                                }
                                movingBaseImage = false
                                imageDragOffset = Offset.Zero
                                if (tool in listOf("Brush", "Eraser", "Line", "Rect", "Ellipse") && activePoints.isNotEmpty()) {
                                    val points = if (activePoints.size == 1 && tool in listOf("Brush", "Eraser")) activePoints + activePoints.first() else activePoints
                                    undoHistory = (undoHistory + listOf(currentLayersState.value)).takeLast(80)
                                    redoHistory = emptyList()
                                    val targetId = currentSelectedLayerIdState.value
                                    layers = currentLayersState.value.map { layer ->
                                        if (layer.id == targetId) layer.copy(
                                            strokes = layer.strokes + PaintStroke(
                                                points, brushColor, brushSize, tool == "Eraser",
                                                when (tool) { "Line" -> "line"; "Rect" -> "rectangle"; "Ellipse" -> "ellipse"; else -> "freehand" },
                                                filledShapes
                                            )
                                        ) else layer
                                    }
                                } else if (tool == "Mask" && activePoints.isNotEmpty()) {
                                    val points = if (activePoints.size == 1) activePoints + activePoints.first() else activePoints
                                    recordUndo()
                                    val targetId = currentSelectedLayerIdState.value
                                    layers = currentLayersState.value.map { layer ->
                                        if (layer.id == targetId) layer.copy(
                                            maskStrokes = layer.maskStrokes + PaintStroke(
                                                points = points,
                                                color = Color.White,
                                                width = brushSize,
                                                eraser = !maskRestoreMode
                                            )
                                        ) else layer
                                    }
                                    status = if (maskRestoreMode) "Mask restored" else "Mask painted"
                                }
                                activePoints = emptyList()
                            }
                        )
                    }
                ) {
                    val cell = 18.dp.toPx()
                    for (y in 0 until (size.height / cell).toInt() + 1) {
                        for (x in 0 until (size.width / cell).toInt() + 1) {
                            drawRect(
                                if ((x + y) % 2 == 0) Color(0xFF383B42) else Color(0xFF30333A),
                                topLeft = Offset(x * cell, y * cell),
                                size = Size(cell, cell)
                            )
                        }
                    }
                    val rect = canvasContentRect(size.width, size.height, sourceBitmap?.width, sourceBitmap?.height)
                    sourceBitmap?.let { bitmap ->
                        drawImage(
                            bitmap.asImageBitmap(),
                            dstOffset = IntOffset((rect.left + imageDragOffset.x).toInt(), (rect.top + imageDragOffset.y).toInt()),
                            dstSize = IntSize(rect.width.toInt().coerceAtLeast(1), rect.height.toInt().coerceAtLeast(1))
                        )
                    }
                    val nativeCanvas = drawContext.canvas.nativeCanvas
                    layers.filter { it.visible }.forEach { layer ->
                        drawLayerPreview(
                            canvas = nativeCanvas,
                            layer = layer,
                            rect = rect,
                            widthScale = rect.width,
                            heightScale = rect.height,
                            selectedTextIndex = selectedTextIndex,
                            showSelection = tool == "Select" && layer.id == selectedLayerId
                        )
                    }
                    if (activePoints.isNotEmpty()) {
                        val previewColor = if (tool == "Eraser") Color(0x80FFFFFF) else brushColor
                        if (tool in listOf("Line", "Rect", "Ellipse")) {
                            drawShapePreview(nativeCanvas, activePoints, rect, previewColor, brushSize,
                                when (tool) { "Line" -> "line"; "Rect" -> "rectangle"; else -> "ellipse" },
                                filled = filledShapes)
                        } else if (tool == "Mask" && activePoints.size > 1) {
                            drawNormalizedStroke(activePoints, rect, if (maskRestoreMode) Color(0xFF65D68A) else Color(0xFFE45B68), brushSize, eraser = false)
                        } else if (activePoints.size > 1) drawNormalizedStroke(activePoints, rect, previewColor, brushSize, eraser = false)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("LAYERS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { addLayer() }) { Text("+ Layer") }
                TextButton(onClick = { duplicateSelectedLayer() }) { Text("Duplicate") }
                TextButton(onClick = { clearSelectedLayer() }) { Text("Clear") }
            }
            selectedLayer?.let { layer ->
                Column(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Opacity", color = Color.LightGray, fontSize = 11.sp)
                        Slider(
                            value = layer.opacity,
                            onValueChange = { setLayerOpacity(layer.id, it) },
                            valueRange = 0f..1f,
                            modifier = Modifier.weight(1f)
                        )
                        Text("${(layer.opacity * 100).toInt()}%", color = Color.White, fontSize = 11.sp)
                    }
                    Text("Blend mode", color = Color.LightGray, fontSize = 11.sp)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    ) {
                        listOf(
                            "normal" to "Normal",
                            "multiply" to "Multiply",
                            "screen" to "Screen",
                            "darken" to "Darken",
                            "lighten" to "Lighten"
                        ).forEach { (mode, label) ->
                            FilterChip(
                                selected = layer.blendMode == mode,
                                onClick = { setLayerBlendMode(layer.id, mode) },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        TextButton(onClick = {
                            renameLayerValue = layer.name
                            showRenameLayerDialog = true
                        }) { Text("Rename") }
                        TextButton(onClick = { moveLayer(layer.id, 1) }) { Text("↑ Up") }
                        TextButton(onClick = { moveLayer(layer.id, -1) }) { Text("↓ Down") }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { deleteSelectedLayer() }) { Text("Delete") }
                    }
                }
            }
            LazyColumn(Modifier.heightIn(max = 132.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                itemsIndexed(layers.reversed(), key = { _, layer -> layer.id }) { _, layer ->
                    Surface(
                        color = if (layer.id == selectedLayerId) Color(0xFF303D52) else Color(0xFF22252B),
                        shape = RoundedCornerShape(8.dp),
                        onClick = { selectedLayerId = layer.id; selectedTextIndex = -1 },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = layer.visible, onCheckedChange = { toggleLayer(layer.id) })
                            Column(Modifier.weight(1f)) {
                                Text(layer.name, color = Color.White, fontSize = 12.sp)
                                Text("${layer.strokes.size} strokes · ${layer.textElements.size} text · ${layer.maskStrokes.size} mask", color = Color.LightGray, fontSize = 10.sp)
                            }
                            TextButton(onClick = { selectedLayerId = layer.id }) { Text(if (layer.id == selectedLayerId) "Active" else "Select", fontSize = 11.sp) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(status, color = Color(0xFFB9C0CB), fontSize = 11.sp)
        }
    }

    if (showResizeDialog) {
        AlertDialog(
            onDismissRequest = { showResizeDialog = false },
            title = { Text("Resize image") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Maximum 12 megapixels to reduce memory pressure.", color = Color.LightGray, fontSize = 12.sp)
                    OutlinedTextField(
                        value = resizeWidthValue,
                        onValueChange = { resizeWidthValue = it.filter(Char::isDigit).take(4) },
                        label = { Text("Width (px)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = resizeHeightValue,
                        onValueChange = { resizeHeightValue = it.filter(Char::isDigit).take(4) },
                        label = { Text("Height (px)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val width = resizeWidthValue.toIntOrNull()
                    val height = resizeHeightValue.toIntOrNull()
                    if (width != null && height != null) resizeSourceBitmap(width, height)
                    else status = "Enter valid pixel dimensions"
                }) { Text("Resize") }
            },
            dismissButton = { TextButton(onClick = { showResizeDialog = false }) { Text("Cancel") } }
        )
    }

    if (showRenameLayerDialog) {
        AlertDialog(
            onDismissRequest = { showRenameLayerDialog = false },
            title = { Text("Rename layer") },
            text = {
                OutlinedTextField(
                    value = renameLayerValue,
                    onValueChange = { renameLayerValue = it.take(80) },
                    label = { Text("Layer name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val cleanName = renameLayerValue.trim()
                    if (cleanName.isNotEmpty()) {
                        val targetId = selectedLayerId
                        val target = layers.firstOrNull { it.id == targetId }
                        if (target != null && target.name != cleanName) {
                            recordUndo()
                            layers = layers.map { layer ->
                                if (layer.id == targetId) layer.copy(name = cleanName) else layer
                            }
                            status = "Layer renamed"
                        }
                        showRenameLayerDialog = false
                    } else {
                        status = "Layer name cannot be empty"
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showRenameLayerDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showTextDialog) {
        AlertDialog(
            onDismissRequest = { showTextDialog = false },
            title = { Text("Text tool") },
            text = {
                Column {
                    Text("Add text to the selected layer. Use the text size, color, and rotation controls in the toolbar. Imported TTF/OTF fonts are used for new text.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = textValue, onValueChange = { textValue = it }, label = { Text("Text to add") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (textValue.isNotBlank()) {
                        val targetId = selectedLayerId
                        recordUndo()
                        layers = layers.map { layer ->
                            if (layer.id != targetId) layer else if (editExistingText && selectedTextIndex in layer.textElements.indices) {
                                layer.copy(textElements = layer.textElements.mapIndexed { index, element ->
                                    if (index == selectedTextIndex) element.copy(text = textValue, size = textSize,
                                        color = textColor, fontPath = importedFontPath ?: element.fontPath,
                                        rotation = textRotation) else element
                                })
                            } else layer.copy(
                                textElements = layer.textElements + TextElement(
                                    text = textValue,
                                    size = textSize,
                                    color = textColor,
                                    fontPath = importedFontPath,
                                    rotation = textRotation
                                )
                            )
                        }
                        status = if (editExistingText) "Text updated" else "Text added to ${selectedLayer?.name ?: "layer"}"
                        textValue = ""
                    }
                    editExistingText = false
                    showTextDialog = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showTextDialog = false }) { Text("Cancel") } }
        )
    }
}

