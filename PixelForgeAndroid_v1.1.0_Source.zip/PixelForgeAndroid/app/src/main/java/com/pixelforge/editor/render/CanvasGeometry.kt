package com.pixelforge.editor.render

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/** Destination rectangle for aspect-fit rendering of a document inside the viewport. */
data class ContentRect(val left: Float, val top: Float, val width: Float, val height: Float)

fun canvasContentRect(viewW: Float, viewH: Float, imageW: Int?, imageH: Int?): ContentRect {
    val aspect = if (imageW != null && imageH != null && imageW > 0 && imageH > 0) imageW.toFloat() / imageH else 1000f / 700f
    val viewAspect = viewW / viewH.coerceAtLeast(1f)
    val w: Float
    val h: Float
    if (viewAspect > aspect) {
        h = viewH
        w = h * aspect
    } else {
        w = viewW
        h = w / aspect
    }
    return ContentRect((viewW - w) / 2f, (viewH - h) / 2f, w.coerceAtLeast(1f), h.coerceAtLeast(1f))
}

fun DrawScope.drawNormalizedStroke(points: List<Offset>, rect: ContentRect, color: Color, width: Float, eraser: Boolean) {
    if (points.size < 2) return
    val path = Path().apply {
        moveTo(rect.left + points.first().x * rect.width, rect.top + points.first().y * rect.height)
        points.drop(1).forEach { lineTo(rect.left + it.x * rect.width, rect.top + it.y * rect.height) }
    }
    if (eraser) {
        // Preview-only approximation; the export renderer uses transparent clearing per layer.
        drawPath(path, Color(0xFF30333A), style = Stroke(width = width, cap = androidx.compose.ui.graphics.StrokeCap.Round))
    } else {
        drawPath(path, color, style = Stroke(width = width, cap = androidx.compose.ui.graphics.StrokeCap.Round))
    }
}

fun Color.toArgbInt(): Int = android.graphics.Color.argb(
    (alpha * 255).toInt(), (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt()
)
