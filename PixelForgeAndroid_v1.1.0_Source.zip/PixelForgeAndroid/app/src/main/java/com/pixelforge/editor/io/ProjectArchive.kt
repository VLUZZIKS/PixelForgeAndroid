package com.pixelforge.editor.io

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AndroidColor
import android.net.Uri
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.pixelforge.editor.model.EditorLayer
import com.pixelforge.editor.model.PaintStroke
import com.pixelforge.editor.model.TextElement
import com.pixelforge.editor.render.toArgbInt
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private const val MANIFEST = "project.json"
private const val BASE_IMAGE = "base.png"

data class LoadedProject(val name: String, val baseBitmap: Bitmap?, val layers: List<EditorLayer>)

/** Writes a portable .pfx ZIP archive containing the document model and its base image. */
fun writeProject(context: Context, uri: Uri, name: String, baseBitmap: Bitmap?, layers: List<EditorLayer>) {
    val output = context.contentResolver.openOutputStream(uri, "w") ?: error("Cannot open destination")
    output.use { writeProjectToStream(context, it, name, baseBitmap, layers) }
}

fun writeProjectToFile(context: Context, file: java.io.File, name: String, baseBitmap: Bitmap?, layers: List<EditorLayer>) {
    val temp = java.io.File(file.parentFile, "${file.name}.tmp")
    temp.outputStream().use { writeProjectToStream(context, it, name, baseBitmap, layers) }
    if (!temp.renameTo(file)) {
        file.outputStream().use { output -> temp.inputStream().use { input -> input.copyTo(output) } }
        temp.delete()
    }
}

private fun writeProjectToStream(context: Context, output: OutputStream, name: String, baseBitmap: Bitmap?, layers: List<EditorLayer>) {
    val entries = linkedMapOf<String, ByteArray>()
    if (baseBitmap != null) {
        val image = ByteArrayOutputStream()
        baseBitmap.compress(Bitmap.CompressFormat.PNG, 100, image)
        entries[BASE_IMAGE] = image.toByteArray()
    }
    val root = JSONObject().put("format", "PixelForge").put("version", 1).put("name", name)
    val layerArray = JSONArray()
    layers.forEachIndexed { layerIndex, layer ->
        val layerJson = JSONObject()
            .put("id", layer.id).put("name", layer.name).put("visible", layer.visible)
            .put("opacity", layer.opacity).put("blendMode", layer.blendMode).put("maskEnabled", layer.maskEnabled)
        val maskStrokes = JSONArray()
        layer.maskStrokes.forEach { stroke ->
            val points = JSONArray()
            stroke.points.forEach { p -> points.put(JSONArray().put(p.x.toDouble()).put(p.y.toDouble())) }
            maskStrokes.put(JSONObject().put("points", points).put("color", stroke.color.toArgbInt())
                .put("width", stroke.width.toDouble()).put("eraser", stroke.eraser).put("shape", stroke.shape).put("filled", stroke.filled))
        }
        layerJson.put("maskStrokes", maskStrokes)
        val strokes = JSONArray()
        layer.strokes.forEach { stroke ->
            val points = JSONArray()
            stroke.points.forEach { p -> points.put(JSONArray().put(p.x.toDouble()).put(p.y.toDouble())) }
            strokes.put(JSONObject().put("points", points).put("color", stroke.color.toArgbInt())
                .put("width", stroke.width.toDouble()).put("eraser", stroke.eraser).put("shape", stroke.shape).put("filled", stroke.filled))
        }
        layerJson.put("strokes", strokes)
        val texts = JSONArray()
        layer.textElements.forEachIndexed { textIndex, element ->
            var fontEntry: String? = null
            val fontFile = element.fontPath?.let { java.io.File(it) }
            if (fontFile != null && fontFile.isFile) {
                val entryName = "fonts/l${layer.id}_t${textIndex}.font"
                fontEntry = entryName
                runCatching { entries[entryName] = fontFile.readBytes() }
            }
            texts.put(JSONObject().put("text", element.text).put("x", element.x.toDouble())
                .put("y", element.y.toDouble()).put("size", element.size.toDouble())
                .put("color", element.color.toArgbInt()).put("rotation", element.rotation.toDouble())
                .put("fontEntry", fontEntry ?: JSONObject.NULL))
        }
        layerJson.put("texts", texts)
        layerArray.put(layerJson)
    }
    root.put("layers", layerArray)
    entries[MANIFEST] = root.toString().toByteArray(Charsets.UTF_8)
    ZipOutputStream(output).use { zip ->
        entries.forEach { (entryName, bytes) ->
            zip.putNextEntry(ZipEntry(entryName))
            zip.write(bytes)
            zip.closeEntry()
        }
    }
}

/** Reads a .pfx archive. Entries are bounded by the archive contents, not extracted to disk. */
fun readProject(context: Context, uri: Uri): LoadedProject {
    val input = context.contentResolver.openInputStream(uri) ?: error("Cannot open project")
    return input.use { readProjectFromStream(context, it) }
}

fun readProjectFromFile(context: Context, file: java.io.File): LoadedProject =
    file.inputStream().use { readProjectFromStream(context, it) }

private fun readProjectFromStream(context: Context, input: InputStream): LoadedProject {
    val entries = mutableMapOf<String, ByteArray>()
    input.use { raw ->
        ZipInputStream(raw).use { zip ->
            var totalRead = 0L
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && (entry.name == MANIFEST || entry.name == BASE_IMAGE || entry.name.startsWith("fonts/"))) {
                    require(entry.name == MANIFEST || entry.name == BASE_IMAGE || entry.name.matches(Regex("fonts/[A-Za-z0-9_.-]+"))) {
                        "Invalid project entry"
                    }
                    val output = ByteArrayOutputStream()
                    val buffer = ByteArray(16 * 1024)
                    var entryRead = 0L
                    while (true) {
                        val count = zip.read(buffer)
                        if (count < 0) break
                        entryRead += count
                        totalRead += count
                        require(entryRead <= 96L * 1024 * 1024 && totalRead <= 160L * 1024 * 1024) {
                            "Project archive is too large"
                        }
                        output.write(buffer, 0, count)
                    }
                    entries[entry.name] = output.toByteArray()
                }
                zip.closeEntry()
            }
        }
    }
    val manifest = entries[MANIFEST]?.toString(Charsets.UTF_8) ?: error("Project manifest missing")
    val root = JSONObject(manifest)
    require(root.optString("format") == "PixelForge") { "Unsupported project format" }
    val base = entries[BASE_IMAGE]?.let { bytes ->
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) null else {
            var sample = 1
            while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > 3072) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            })
        }
    }
    val layersJson = root.optJSONArray("layers") ?: JSONArray()
    val cacheDir = java.io.File(context.cacheDir, "pixelforge_project_fonts").apply { mkdirs() }
    val layers = (0 until layersJson.length()).map { i ->
        val item = layersJson.getJSONObject(i)
        val strokesJson = item.optJSONArray("strokes") ?: JSONArray()
        val strokes = (0 until strokesJson.length()).map { j ->
            val stroke = strokesJson.getJSONObject(j)
            val pointsJson = stroke.optJSONArray("points") ?: JSONArray()
            val points = (0 until pointsJson.length()).map { k ->
                val point = pointsJson.getJSONArray(k)
                Offset(point.getDouble(0).toFloat(), point.getDouble(1).toFloat())
            }
            PaintStroke(points, Color(stroke.optInt("color", AndroidColor.BLACK)), stroke.optDouble("width", 12.0).toFloat(), stroke.optBoolean("eraser"), stroke.optString("shape", "freehand"), stroke.optBoolean("filled", false))
        }
        val maskJson = item.optJSONArray("maskStrokes") ?: JSONArray()
        val maskStrokes = (0 until maskJson.length()).map { j ->
            val stroke = maskJson.getJSONObject(j)
            val pointsJson = stroke.optJSONArray("points") ?: JSONArray()
            val points = (0 until pointsJson.length()).map { k ->
                val point = pointsJson.getJSONArray(k)
                Offset(point.getDouble(0).toFloat(), point.getDouble(1).toFloat())
            }
            PaintStroke(points, Color(stroke.optInt("color", AndroidColor.WHITE)),
                stroke.optDouble("width", 12.0).toFloat(), stroke.optBoolean("eraser"),
                stroke.optString("shape", "freehand"), stroke.optBoolean("filled", false))
        }
        val textsJson = item.optJSONArray("texts") ?: JSONArray()
        val texts = (0 until textsJson.length()).map { j ->
            val text = textsJson.getJSONObject(j)
            val fontEntry = text.optString("fontEntry").takeIf { it.isNotBlank() && it != "null" }
            val fontPath = fontEntry?.let { entryName ->
                entries[entryName]?.let { bytes ->
                    val file = java.io.File(cacheDir, entryName.substringAfterLast('/'))
                    runCatching { file.writeBytes(bytes); file.absolutePath }.getOrNull()
                }
            }
            TextElement(text.optString("text"), text.optDouble("x", .5).toFloat(), text.optDouble("y", .5).toFloat(),
                text.optDouble("size", 48.0).toFloat(), Color(text.optInt("color", AndroidColor.BLACK)), fontPath,
                text.optDouble("rotation", 0.0).toFloat())
        }
        val blendMode = item.optString("blendMode", "normal").takeIf {
            it in setOf("normal", "multiply", "screen", "darken", "lighten")
        } ?: "normal"
        EditorLayer(item.optInt("id", i + 1), item.optString("name", "Layer ${i + 1}"), item.optBoolean("visible", true),
            item.optDouble("opacity", 1.0).toFloat().coerceIn(0f, 1f), strokes, texts, blendMode,
            maskStrokes, item.optBoolean("maskEnabled", true))
    }
    return LoadedProject(root.optString("name", "Imported project"), base, layers.ifEmpty { listOf(EditorLayer(1, "Paint layer 1")) })
}
